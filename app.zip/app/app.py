from flask import Flask, render_template, request, redirect
from db import autora, novels
from re import *
import requests
import json
import db

import shelve

app = Flask(__name__)

#cria index
@app.route('/')
def index():
    return render_template('index.html')

#pagina autora
@app.route('/autora')
def autoraf():
    return render_template('autora.html', title='Autora', autora=autora)

#pagina novels
@app.route('/novels')
def novelsf():
    return render_template('novels.html', title='Novels', novels=novels)

#pagina individual de cada novel
@app.route('/novels/novel/<id_>')
def novelf(id_):
    return render_template('novel.html', p = novels[int(id_)])


#pesquisa no url por expressões presentes no titulo
@app.route('/pesquisa/<exp>')
def grep_p(exp):
    r=[p for p in novels if search(exp, p['title'] + p['sinopsis'])]
    return render_template('novels.html', title=f'Novels com  "{exp}" no Título ou na Sinopse', novels=r)
   


#tentativa de inserir novos novels, não funciona
@app.route('/novels', methods=['GET'])
def get_novels():
    res = requests.get('http://localhost:5000/api/novels')
    ps = json.loads(res.content)

    return render_template('novels.html', novels=ps)

@app.route('/novels', methods=['POST'])
def post_novel():
    data = dict(request.form)
    print(data)
    requests.post('http://localhost:5000/api/novels', data=data)


    return redirect('http://localhost:5000/novels')


#API
@app.route('/api/novels', methods=['POST'])
def api_post_novel():
    
    data = dict(request.form)
    db.insert(data)

    return json.dumps(db.find_all()) 


