import shelve

autora = [
    'Tânia Alexandra',
    'pg39392',
    'Mestrado em Humanidades Digitais'
]

novels = [   
     {
        'id': 0,
        'title': 'Dubliners - "The Dead"',
        'author': 'James Joyce',
        'published': 'Junho, 1914',
        'sinopsis':  'The Dead, alongside different stories in Joyces Dubliners, happens in Dublin, Ireland, in the mid twentieth century. It is winter, and the characters are going to a vacation party at the home of the fundamental characters aunties. Toward the finish of the story, the setting movements to a taxi ride through the early morning day off then to a lodging where the hero and his better half will go through the night. An educator and a part-timr book reviewer named Gabriel Conroy goes to a Christmastime party tossed by his aunties (Kate and Julia Morkin, great ladies in the realm of Dublin music) at which he hits the dance floor with an individual instructor and conveys a concise discourse. As the gathering is separating, Gabriel observes his significant other, Gretta, tuning in to a melody sung by the eminent tenor Bartell DArcy, and the force of her emphasis on the music makes him feel both wistful and lewd. In a lodging later, Gabriel is crushed to find that he has misjudged Grettas emotions; she has been moved by the memory of a youthful darling named Michael Furey who went before Gabriel, and who kicked the bucket for the love of Gretta. Gabriel understands that she has never felt also enthusiastic about their marriage. He feels alone and significantly mortal, however profoundly associated unexpectedly with others.'
    },
    {
        'id': 1,
        'title': 'Tess of the dUrbervilles',
        'author': 'Thomas Hardy',
        'published': '1891',
        'sinopsis': 'After her ruined family learns of its honorable ancestry, gullible Tess Durbeyfield is sent by her lazy dad and uninformed mother to make an appeal to a close by affluent family who bear the hereditary name dUrberville. Tess, appealing and guiltless, is lured by lewd Alec dUrberville and subtly bears a kid, Sorrow, who bites the dust in earliest stages. Later functioning as a dairymaid, she meets and weds Angel Clare, a hopeful man of honor who rejects Tess subsequent to learning of her past on their wedding night. Genuinely deprived and monetarily ruined, Tess is caught by need into giving in by and by to dUrberville, yet she kills him when Angel returns.'
    },
    {
        'id': 2,
        'title': 'The Mark on the Wall',
        'author': 'Virginia Wolf',
        'published': '1917',
        'sinopsis': 'An unknown first-individual storyteller reviews a second in the center of January when she first gazes upward and sees an imprint on the divider. She is lost in a dream while gazing at the consuming coals in the fire, thinking about a "crimson flag flapping from the castle tower" and red knights riding up dark rocks. Seeing the blemish on the divider intrudes on her dream. It is "a small round mark, black upon the white wall, about six or seven inches above the mantelpiece." The storyteller muses, "How readily our thoughts swarm upon a new object," attempting to sort out what it is and what it implies with regards to different environmental factors. She contemplates whether the imprint was made by the past proprietors of the house, and thinks about how weird it is that she will probably never observe them again or realize what occurred next in their lives.  The storyteller considers getting up to research the imprint however understands that she could always be unable to state for certain where it came from. This line of reasoning leads her to consider "the inaccuracy of thought" and how little control individuals have over their environmental factors and assets. Items are much of the time lost. She thinks about how life passes by instantly, contrasting it with going on the underground (tram) at 50 miles for each hour just to be "shot out at the feet of God entirely naked!" She contemplates the notion that life passes rapidly and is full of "waste and repair; all so casual, all so haphazard.'
    },
    {
        'id': 3,
        'title': 'The Garden Party',
        'author': 'Katherine Mansfield',
        'published': '1922',
        'sinopsis': 'In “The Garden Party”, Katherine Mansfield explored the use of the third person narration from Laura’s point of view, giving the reader a simultaneous insight into the main character’s thoughts while witnessing her actions. Mansfield allows the reader to know Laura’s exclusive perspective, while the story evolves, which is only possible by her frequent use internal monologues. (She is also known for her ambiguous endings) Her preference for the female perspective was unprecedented for that time which was clear not only in her work but also in the life when she decided that writing would be her career and not marriage. As an unconventional short story, “The Garden Party” begins in medias res, with no traditional introduction and it is told over the course of few hours. Just as her contemporaries, Mansfield chosen to focus on the center of her plot on a single moment in time, demonstrating how small events, such as garden parties, can change the character perspective on life leading to life alternating results. For instance, Laura Sheridan’s view of the world is shaken by the dead of her neighbor, Mr. Scott, which makes reevaluate her thoughts on relations.'
    },
    {
        'id': 4,
        'title': 'The Bloody Chamber And Other Stories ',
        'author': 'Angela Carter',
        'published': '1979',
        'sinopsis': 'The anonymous storyteller of "The Bloody Chamber" is a 17-year-old young lady from Paris who weds a rich Marquis notwithstanding her moms reservations. After the wedding she travels with him to his isolated manor where, on their special night, he leaves her with the keys to all the entryways in the stronghold however advises her never to utilize the littlest one. The young lady utilizes the prohibited key and finds the tormented and ridiculous assemblages of the Marquis previous spouses. The Marquis gets back and educates her he will rebuff her by executing, yet her mom shows up in the nick of time to shoot the Marquis dead with her pistol.'
    },
    {
        'id': 5,
        'title': 'Frankenstein',
        'author': 'Mary Shelly',
        'published': '1823',
        'sinopsis': 'The novel’s origin: when in Geneva, the Shelley’s’ had been reading ghost stories when Byron suggested that they should write a ghost story. While writing her, Mary Shelley was inspired on a conversation between Byron and Shelley upon the “the principle of life”. She seems to have had a vision of her scientist-hero animating a corpse. Frankenstein is a product of the 18th-century trend on Gothic novels of horro, but it is an innovative work in many aspects, like its protagonist. It has been considered a tale warning about the dangers that society may encounter when applying experimental science. CENTRAL THEMES- The scientist Dr Frankenstein is an example of the Faustian and Promethean spirit of ambition that, according to M. Shelley, leads ultimately to his destruction and the death of all he loves. The being that he creates represents the Romantic concern with human isolation. It is a modern myth because of the society’s concerns when it comes to the human creative power.'
    },
    {
        'id': 6,
        'title': 'The Picture of Dorian Gray',
        'author': 'Oscar Wilde',
        'published': 'Julho, 1890',
        'sinopsis': 'The novel is about a young man named Dorian Gray, the subject of the painting by Basil Hallward. The painter believes that Dorian’s beauty can change his art. Dorian is overwhelmed by how Lord Henry Wotton views the world convincing Dorian to follow a new hedonism and convincing him that beauty and fulfillment of the senses are the only things worth pursuing in life. After realizing that his envied beauty will fade, he decides to sell his soul in order to remain young and only the portrait, made by Basil, to age. Because of the fulfillment of his wish and the influence of Lord Henry, Dorian chases a life of pleasures while the portrait ages and reminds him how each of his acts affect his soul. The main characters are then Dorian Gray, Lord Henry Wotton and Basil Hallward.'
    },
    {
        'id': 7,
        'title': 'The Goblin Market',
        'author': 'Christina Rossetti ',
        'published': '1862',
        'sinopsis': 'Goblin Market and Other Poems” was the collection that launched Rossetti as the main female poet of the time and received critical praise. At first the story seems to be about 2 sisters and their adventures with goblin but for critics the story has various interpretations: one reading is religious, and the other focuses on gender and sexuality. In the religious interpretation, the characters are compared to figures of the bible for example, Laura represents Eve, the goblin men are the equivalent of Satan and Lizzie is the Christ figure. The fruits represent the temptations of life and just like in the Bible; the fruit brings death and destruction. In the second interpretation it is possible to see symbols of repressed sexual desire and sexual violence.  In the beginning, both Laura and Lizzie are described as innocent, but Laura’s curiosity appears to win. Rossetti then creates a struggle between the costs of chasing lust and the need to explore human desires.'
    },
    {
        'id': 8,
        'title': 'Wuthering Heights ',
        'author': 'Emily Brontë',
        'published': '1847',
        'sinopsis': 'The novel, “Wuthering Heights” is considered to be different from the normal English Novel. The characters obey to their natures and it seems to not have a moral dimension. Heathcliff is the protagonist and his life is depicted as a ridicule capitalist activity. Nelly Dean is a female narrator that also shows the reader a world where men fight for the favors of women. Wuthering Height’s household is considered a family where women are in charge and where patriarchal laws are confronted. The novel has a big variety of languages with dialect variations. Typical of the Victorian period, Wuthering Heights has elements of the Romantic Gothic and the Domestic realistic fiction.  Catherine Earnshaw is the heroine, she breaks the Victorian female stereotypes by blending masculine and feminine qualities. Catherines challenge of gender norms is portrayed positively, while the feminine qualities embodied by her husband, Edgar, are not. The two genres are mixed and continuous so as to produce a structural continuity. Considerations of class status often inform the characters’ motivations, such as Catherine’s decision to marry Edgar. The Lintons are relatively firm in their gentry status but still go through a lot of troubles to prove their status through their behaviours, while the Earnshaws are not that secure socially.'
    },
    {
        'id': 9,
        'title': 'Hard Times',
        'author': 'Charles Dickens',
        'published': '1854',
        'sinopsis': 'In “Hard Times”, published in “Household Words”, it’s about the English Society and focuses in emphasizing the social and economic pressures of the times. It is about the condition of the factory life and its consequences on the workers who are victims of its danger and exhausting boredom. Dickens itself traveled to Preston to personally experience the life of an industrial city. The Utilitarians were great targets of the novel because Dickens thought that the pursuit of a rationalized society could cause despair, so he satirizes radical Utilitarians as he also wants to fight for a reform of the working conditions. The most important themes are, then, the opposites between Fact and Fancy, the importance of femininity and the mechanization of humans as the industrialization seems to turn humans into machines by preventing them of having emotions and imagination.'
    },
    {
        'id': 10,
        'title': 'Macbeth',
        'author': 'William Shakespeare',
        'published': '1603/1607',
        'sinopsis': 'Three witches tell the Scottish general Macbeth that he will be King of Scotland. Encouraged by his wife, Macbeth kills the king, becomes the new king, and kills more people out of paranoia. Civil war erupts to overthrow Macbeth, resulting in more death.'
    },
    {
        'id': 11,
        'title': 'At the Hawks Well',
        'author': ' William Butler Yeats',
        'published': '1916',
        'sinopsis': 'The play “At the Hawk’s Well”, from Yeats, can be considered the first experimental play since it was the first Irish play that also included features of the Japanese theater Noh, which helped Yeats write a different form of drama. Some of those features brought from the Japanese theater are the songs and the music played that it is heard throughout the whole play. Another feature is also how the play and the stage are simplified by having fewer characters and props (the use of a cloth to represent the main object of the play: the well). The plot of the play is also very simple and entirely in verse. Although it was the desire of Yeats to introduce the Japanese influences to his work, he never forgot to insert the Irish perspective, building then a bridge between this two worlds and also being able to introduce symbolism to his plays contrarily to the more realistic theater that Yeats was used to deliver to his audience.'
    },
    {
        'id': 12,
        'title': 'The Pot of Broth',
        'author': 'William Butler Yeats',
        'published': '1905',
        'sinopsis': '“The Pot of Broth”, from William Butler Yeats, has as a main character the Tramp. He is a homeless person, a traveller that is able to make people believe that the stone that he carries is magical and with it is able to make a pot of broth. For that to be accomplished, we notice that the Tramp has some set of characteristics that makes him believable. The most striking characteristic is of a good story-teller. He has the gift of the word and he’s able to entice the audience and make everybody believe him. The whole play revolves around the story that the Tramp is able to create about the “magical” stone, “It can do many things, and what it’s going to do now is to make a drop of broth for my dinner”.  However, this quality also shows how manipulative the Tramp is in order to make people believe that the stone is in fact magical and, able to actually make the broth “No one in the world but myself has one ma’am, and no other stone in the world has the same power, for it has enchantment on it”.  The Tramp is also very astute, always alert and looking for food to put in the pot while distracting the couple with his stories, for example when he distracts John to use the ham bone to stir the pot even when he doesn’t even mention the ham bone “[Looking around at the ham bone] Give me the loan of a kippeen to stir the pot with… (…) I didn’t say a ham bone I said a hare-skin coat.”. Right from the beginning, Tramp is able to entice John but Sibby was in doubt, so Tramp engages in captivating Sibby’s attention in order to make her believe in his tale. He starts by distracting and sweet talking her with tales and compliments about all the man that became heartbroken when she married John, “Did you ever heard what the boys in your own parish were singing after you being married from them- such of them that had any voice at all and not chocked with crying, or senseless with the drop of drink they took to comfort them and to keep their wits from going, with the loss of you.”. All of this qualities show how wise the Tramp actually is, in order to cook a meal while making the couple believe the power of the stone.'
    },
    {
        'id': 13,
        'title': 'Riders to the Sea',
        'author': 'John Synge',
        'published': '1904',
        'sinopsis': '“Riders to the Sea” is a single act tragedy written by John Synge. It is one of the most important plays to be played in the National Irish Theater since it was the first to ever be translated. The play is majorly focused in the human inability to fight against the sea. Is focused on the struggle men have once they embrace that specific life to provide and sustain their families. However, the play itself focuses more on the part of the women that stay, waiting for their sons or husbands to come back which sometimes doesn’t happen, so they stay and grief their lost. In this case, the audience witnesses a case of a mother that already lost 5 of their 6 sons, and her last son is going to the sea against her will. So, the main character is the mother, Maurya, she is a widow that lost her husband as well as their 5 sons because of the sea. She is the wisest character in play since she is aware of the conditions of the weather and sea (contrarily to the young priest); she’s also mentally very strong by witnessing the birth and dead of their children; but also, she is a sign of resilience and endurance since she is a suffering mother but at the same time someone that is able to understand nature as nobody else, as also was able to get the holy water and do what she had to do to the body of her son. All her actions are a clear sign of strength. “MAURYA: Michael has a clean burial in the far north, by the grace of the Almighty God. Bartley will have a fine coffin out of the white boards, and a deep grave surely. What more can we want than that? No man at all can be living for ever, and we must be satisfied."'
    }
]


def find_all():
    with shelve.open('new_novels.db') as s:
        return list(s.keys())

def insert(novel_data):
    with shelve.open('new_novels.db', writeback=True) as s:
        s[novel_data['title']] = novel_data['sinopsis']
        return list(s.keys())