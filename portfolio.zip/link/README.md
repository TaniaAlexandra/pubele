# Trabalho de Publicação Eletrónica

1. abrir e ler o file 'portfolio.xml'

2. para o index, encontrar a etiqueta portfolio e dentro dessa encontrar as estiquetas de 'title', 'date', todas as informações dentro da estiqueta 'student' e ainda, colocar em lista todas as obras ('novel') que fazem parte deste trabalho com o seu respetivo link 

3. para os criar html da cada novel, encontro todas as etiquetas 'novel' no meu portfolio e retiro as etiquetas dentro dessa com a denominação de 'ntitle'(titulo do novel), 'author', 'published', 'descrnovel' e 'link'. Juntamente coloquei algumas etiquetas html para estilizar a página.
e para de seguida, ao criar cada novel separadamente em formato html, colocar todas as especificidades transpostas anteriormente

        n=1 e o n=+1 é para que o comando faça mais do que um novel

