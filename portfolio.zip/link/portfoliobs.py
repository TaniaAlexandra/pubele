from bs4 import BeautifulSoup as bs

file = 'portfolio.xml'
with open (file) as f:
	d=f.read()

ad = bs(d, "xml")


n=1 

for index in ad.find_all("portfolio"):

	I="<h1><center>Obras lidas em Literatura inglesa</center></h1>"
	I+=f'<h2><center>{index.parent.date}</center></h2>'
	I+=f'<hr><b>Criado por:</b></hr>'
	I+=f'<p>{index.parent.student.n}</p>'
	I+=f'<p>{index.parent.student.number}</p>'
	I+=f'<p>{index.parent.student.email}</p>'
	I+=f'<p>{index.parent.student.masters}</p>'
	I+=f'<hr>{index.parent.description}</hr> </a>'	
	I+=f'<hr><p><li><a href="novel1.html" title="de James Joyce" target="_blank">Dubliners</a></li></p>'
	I+=f'<p><li><a href="novel2.html" title="de Thomas Hardy" target="_blank">Tess of the d"Urbervilles </a></li></p>'
	I+=f'<p><li><a href="novel3.html" title="de Virginia Wolf" target="_blank">The Mark on the Wall</a></li></p>'
	I+=f'<p><li><a href="novel4.html" title="de Katherine Mansfield" target="_blank">The Garden Party</a></li></p>'
	I+=f'<p><li><a href="novel5.html" title="de Angela Carter" target="_blank">The Bloody Chamber And Other Stories</a></li></p>'
	I+=f'<p><li><a href="novel6.html" title="de Mary Shelly" target="_blank">Frankenstein</a></li></p>'
	I+=f'<p><li><a href="novel7.html" title="de Oscar Wilde" target="_blank">The Picture of Dorian Gray</a></li></p>'
	I+=f'<p><li><a href="novel8.html" title="de Christina Rossetti" target="_blank">The Goblin Market</a></li></p>'
	I+=f'<p><li><a href="novel9.html" title="de Emily Brontë" target="_blank">Wuthering Heights</a></li></p>'
	I+=f'<p><li><a href="novel10.html" title="de Charles Dickens" target="_blank">Hard Times</a></li></p>'
	I+=f'<p><li><a href="novel11.html" title="de William Shakespeare" target="_blank">Macbeth</a></li></p>'
	I+=f'<p><li><a href="novel12.html" title="de William Butler Yeats" target="_blank">At the Hawks Well</a></li></p>'
	I+=f'<p><li><a href="novel13.html" title="de William Butler Yeats" target="_blank">The Pot of Broth </a></li></p>'
	I+=f'<p><li><a href="novel14.html" title="de John Synge" target="_blank">Riders to the Sea</a></li></p></hr>'

	I=f'<img src="ILCH-pt.jpg" alt="Logo ILCH" width="120" height="100" style="float:right">' + I

	with open(f'index.html', 'w') as f:
		f.write(I)


for novel in ad.find_all("novel"):

	N=f'<h1><center>{novel.parent.ntitle}</center></h1>'
	N+=f'<h3><center>{novel.parent.author}</center></h3>'
	N+=f'<p><center>{novel.parent.published}</center></p>'
	N+=f'<p>{novel.parent.descrnovel}</p>'
	N+=f'<p><center>{novel.parent.link}</center></p>'

	with open(f'novel{n}.html', 'w') as f:
		f.write(N)

	n+=1


